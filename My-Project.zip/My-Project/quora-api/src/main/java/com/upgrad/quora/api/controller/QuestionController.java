package com.upgrad.quora.api.controller;

import com.upgrad.quora.api.model.*;
import com.upgrad.quora.service.business.AuthorizationService;
import com.upgrad.quora.service.business.QuestionService;
import com.upgrad.quora.service.common.EndPointIdentifier;
import com.upgrad.quora.service.entity.QuestionEntity;
import com.upgrad.quora.service.entity.UserAuthEntity;
import com.upgrad.quora.service.exception.AuthorizationFailedException;
import com.upgrad.quora.service.exception.InvalidQuestionException;
import com.upgrad.quora.service.exception.UserNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Controller
public class QuestionController {

    @Autowired
    QuestionService questionService;

    @Autowired
    AuthorizationService authorizationService;

    @RequestMapping(method = RequestMethod.POST,path="/question/create", consumes= MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public ResponseEntity<QuestionResponse> createQuestion(@RequestHeader("authorization") String accessToken, final QuestionRequest questionRequest) throws AuthorizationFailedException{
        final QuestionEntity questionEntity=new QuestionEntity();
        UserAuthEntity userAuthEntity=authorizationService.getUserAuthEntity(accessToken, EndPointIdentifier.QUESTION_ENDPOINT);
        questionEntity.setUuid(UUID.randomUUID().toString());
        questionEntity.setUser_id(userAuthEntity.getUser());
        questionEntity.setContent(questionRequest.getContent());
        questionEntity.setDate(ZonedDateTime.now());
        final QuestionEntity createdQuestionEntity = questionService.createQuestion(questionEntity);
        QuestionResponse questionResponse = new QuestionResponse().id(createdQuestionEntity.getUuid())
                .status("QUESTION CREATED");

        return new ResponseEntity<>(questionResponse, HttpStatus.OK);
    }

    @RequestMapping(method=RequestMethod.GET, path="/question/all", produces=MediaType.APPLICATION_JSON_UTF8_VALUE)
    public ResponseEntity<QuestionDetailsResponse> getAllQuest(@RequestHeader("authorization") String accessToken) throws AuthorizationFailedException{
        List<QuestionEntity> questionEntityList=questionService.getAllQuest(accessToken);
        List<QuestionDetailsResponse> questionDetailsResponseList=new ArrayList<QuestionDetailsResponse>();
        if(!questionEntityList.isEmpty())
        {
            for(QuestionEntity x : questionEntityList){
                QuestionDetailsResponse questionDetailsResponse=new QuestionDetailsResponse();
                questionDetailsResponse.setId(x.getUuid());
                questionDetailsResponse.setContent(x.getContent());
                questionDetailsResponseList.add(questionDetailsResponse);
            }
        }
        return new ResponseEntity(questionDetailsResponseList, HttpStatus.OK);
    }
    @RequestMapping(method = RequestMethod.PUT,path="/question/edit/{questionId}", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public ResponseEntity<QuestionEditResponse> editQuestionContent(@RequestHeader("authorization") String accessToken, @PathVariable String questionId, QuestionEditRequest questionEditRequest) throws AuthorizationFailedException, InvalidQuestionException {


        QuestionEntity questionEntity = questionService.checkQuestion(accessToken, questionId);
        questionEntity.setContent(questionEditRequest.getContent());
        QuestionEntity updatedQuestionEntity = questionService.updateQuestion(questionEntity);
        QuestionEditResponse questionEditResponse = new QuestionEditResponse().id(updatedQuestionEntity.getUuid()).status("QUESTION EDITED");
        return new ResponseEntity<>(questionEditResponse, HttpStatus.OK);
    }
    @RequestMapping(method = RequestMethod.DELETE,path = "/question/delete/{questionId}")
    public ResponseEntity<QuestionDeleteResponse> questionDelete(@RequestHeader("authorization") String accessToken,@PathVariable String questionId) throws AuthorizationFailedException, InvalidQuestionException {
        String id = questionService.deleteQuestion(questionId, accessToken);
        QuestionDeleteResponse questionDeleteResponse = new QuestionDeleteResponse().id(id)
                .status("QUESTION DELETED");
        return new ResponseEntity<>(questionDeleteResponse, HttpStatus.OK);
    }
    @RequestMapping(method = RequestMethod.GET,path = "/question/all/{userId}")
    public ResponseEntity<List<QuestionDetailsResponse>> getAllQuestionsByUser(@RequestHeader("authorization") String accessToken,
                                                                               @PathVariable String userId) throws AuthorizationFailedException, UserNotFoundException {
        List<QuestionEntity> questionEntityList = questionService.getAllQuestionsByUser(accessToken, userId);
        List<QuestionDetailsResponse> questionDetailsResponseList = new ArrayList<QuestionDetailsResponse>();
        for (QuestionEntity n : questionEntityList) {
            QuestionDetailsResponse questionDetailsResponse = new QuestionDetailsResponse();
            questionDetailsResponse.setId(n.getUuid());
            questionDetailsResponse.setContent(n.getContent());
            questionDetailsResponseList.add(questionDetailsResponse);
        }
        return new ResponseEntity<>(questionDetailsResponseList, HttpStatus.OK);
    }
    }
