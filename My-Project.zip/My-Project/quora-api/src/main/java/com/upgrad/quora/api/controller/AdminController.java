package com.upgrad.quora.api.controller;

import com.upgrad.quora.api.model.UserDeleteResponse;
import com.upgrad.quora.service.business.AdminService;
import com.upgrad.quora.service.business.AuthorizationService;
import com.upgrad.quora.service.business.UserService;
import com.upgrad.quora.service.common.EndPointIdentifier;
import com.upgrad.quora.service.entity.UserAuthEntity;
import com.upgrad.quora.service.entity.UserEntity;
import com.upgrad.quora.service.exception.AuthorizationFailedException;
import com.upgrad.quora.service.exception.UserNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

@Controller
public class AdminController implements EndPointIdentifier {

    @Autowired
    UserService userService;

    @Autowired
    AuthorizationService authorizationService;

    @Autowired
    AdminService adminService;


    @RequestMapping(method = RequestMethod.DELETE ,path = "/admin/user/{userId}")
    public ResponseEntity<UserDeleteResponse> userDelete(@RequestHeader("authorization") String accessToken,
                                                         @PathVariable String userId) throws
            AuthorizationFailedException, UserNotFoundException {

        UserAuthEntity userAuthEntity = authorizationService.getUserAuthEntity(accessToken, EndPointIdentifier.ADMIN_ENDPOINT);
        UserEntity userEntity = userAuthEntity.getUser();
        if (userEntity.getRole().equals("nonadmin"))
        {
            throw new AuthorizationFailedException("ATHR-003","Unauthorized Access, Entered user is not an admin");
        }
        else {
            String id = adminService.deleteUserByUuid(userId);
            UserDeleteResponse userDeleteResponse = new UserDeleteResponse().id(id).status("USER SUCCESSFULLY DELETED");
            return new ResponseEntity<UserDeleteResponse>(userDeleteResponse, HttpStatus.OK);
        }
    }
}