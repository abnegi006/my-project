package com.upgrad.quora.api.controller;

import com.upgrad.quora.api.model.UserDetailsResponse;
import com.upgrad.quora.service.business.AuthorizationService;
import com.upgrad.quora.service.business.UserService;
import com.upgrad.quora.service.common.EndPointIdentifier;
import com.upgrad.quora.service.entity.UserAuthEntity;
import com.upgrad.quora.service.entity.UserEntity;
import com.upgrad.quora.service.exception.AuthorizationFailedException;
import com.upgrad.quora.service.exception.UserNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class CommonController implements EndPointIdentifier {

    @Autowired
    AuthorizationService authorizationService;

    @Autowired
    UserService userService;
    @RequestMapping(method = RequestMethod.GET, path = "/userprofile/{userId}", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public ResponseEntity<UserDetailsResponse> userProfile(@RequestHeader("authorization") String accessToken , @PathVariable String userId) throws AuthorizationFailedException, UserNotFoundException {
        UserAuthEntity userAuthTokenEntity = authorizationService.getUserAuthEntity(accessToken,USER_ENDPOINT);
        UserEntity userEntity = userService.getUserByUuid(userId);
        final UserDetailsResponse userDetailsResponse = new UserDetailsResponse().userName(userEntity.getUsername()).firstName(userEntity.getFirstname()).lastName(userEntity.getLastname()).emailAddress(userEntity.getEmail()).contactNumber(userEntity.getContactnumber()).country(userEntity.getCountry()).dob(userEntity.getDob()).aboutMe(userEntity.getAboutme());
        return new ResponseEntity<UserDetailsResponse>(userDetailsResponse, HttpStatus.OK);
    }

}

