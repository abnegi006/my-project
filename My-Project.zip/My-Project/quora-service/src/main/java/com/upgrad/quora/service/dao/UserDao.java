package com.upgrad.quora.service.dao;

import com.upgrad.quora.service.entity.UserAuthEntity;
import com.upgrad.quora.service.entity.UserEntity;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

@Repository
public class UserDao {

    @PersistenceContext
    private EntityManager entityManager;

    public UserEntity createUser(UserEntity userEntity) {

        entityManager.persist(userEntity);
        return userEntity;
    }

    public UserEntity userByUserName(String username) {

        try {
            return entityManager.createNamedQuery("userByUserName", UserEntity.class)
                    .setParameter("username", username).getSingleResult();
        } catch (NoResultException nre) {

            return null;
        }

    }

    public UserEntity userByEmail(String email) {

        try {
            return entityManager.createNamedQuery("userByEmail", UserEntity.class)
                    .setParameter("email", email).getSingleResult();
        } catch (NoResultException nre) {

            return null;
        }
    }

    public UserAuthEntity createAuth(final UserAuthEntity userAuthEntity) {

        entityManager.persist(userAuthEntity);
        return userAuthEntity;
    }

    public UserAuthEntity userByAccessToken(String accessToken) {

        try {
            return entityManager.createNamedQuery("userByAccessToken", UserAuthEntity.class)
                    .setParameter("accessToken", accessToken).getSingleResult();
        } catch (NoResultException nre) {

            return null;
        }
    }
    public UserEntity findUserByUuid(String uuid) {

        try {
            return entityManager.createNamedQuery("userByUUID", UserEntity.class)
                    .setParameter("uuid", uuid).getSingleResult();
        } catch (NoResultException nre) {

            return null;
        }
    }
    public void deleteUserByUuid(String uuid) {

        String query = "delete from UserEntity u where u.uuid = :uuid";

        Query finalQuery = entityManager.createQuery(query)
                .setParameter("uuid", uuid);
        finalQuery.executeUpdate();
    }
}
