package com.upgrad.quora.service.business;

import com.upgrad.quora.service.common.EndPointIdentifier;
import com.upgrad.quora.service.dao.QuestionDao;
import com.upgrad.quora.service.dao.UserDao;
import com.upgrad.quora.service.entity.QuestionEntity;
import com.upgrad.quora.service.entity.UserAuthEntity;
import com.upgrad.quora.service.entity.UserEntity;
import com.upgrad.quora.service.exception.AuthorizationFailedException;
import com.upgrad.quora.service.exception.InvalidQuestionException;
import com.upgrad.quora.service.exception.UserNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;



@Service
public class QuestionService implements EndPointIdentifier {

    @Autowired
    QuestionDao questionDao;

    @Autowired
    UserDao userDao;

    @Autowired
    UserAuthValidifierService userAuthValidifierService;

    @Autowired
    QuestionValidy questionValidy;

    @Transactional(propagation = Propagation.REQUIRED)
    public QuestionEntity createQuestion(final QuestionEntity questionEntity) {

        return questionDao.createQuestion(questionEntity);

    }
    @Transactional(propagation = Propagation.REQUIRED)
    public List<QuestionEntity> getAllQuest(String accessToken) throws AuthorizationFailedException {
        UserAuthEntity userAuthTokenEntity = userDao.userByAccessToken(accessToken);

        List<QuestionEntity> questionEntityL= new ArrayList<>();

        if(userAuthValidifierService.userAuthValidityCheck(accessToken,GET_ALL_QUESTIONS)){
            questionEntityL= questionDao.getAllQuest();
        }
        return questionEntityL;
    }
    @Transactional(propagation = Propagation.REQUIRED)
    public QuestionEntity checkQuestion(String accessToken, String questionId) throws AuthorizationFailedException, InvalidQuestionException {

        UserAuthEntity userAuthEntity = userDao.userByAccessToken(accessToken);
        QuestionEntity exQuestionEntity= null;
        if(userAuthValidifierService.userAuthValidityCheck(accessToken,CHECK_QUESTION)){
            UserEntity user = userAuthEntity.getUser();

            exQuestionEntity = questionValidy.checkQuestion(questionId);

            if (!user.equals(exQuestionEntity.getUser_id())) {
                throw new AuthorizationFailedException("ATHR-003", "Only the question owner can edit the question");
            } else {
                return exQuestionEntity;
            }
        }
        return exQuestionEntity;
    }
    @Transactional(propagation = Propagation.REQUIRED)
    public QuestionEntity updateQuestion(QuestionEntity questionEntity) {
        return questionDao.updateQuestion(questionEntity);
    }

    @Transactional(propagation = Propagation.REQUIRED)
    public String deleteQuestion(String questionId, String accessToken) throws AuthorizationFailedException, InvalidQuestionException {
        UserAuthEntity userAuthTokenEntity = userDao.userByAccessToken(accessToken);

        String deletedQuestionid=null;
        if(userAuthValidifierService.userAuthValidityCheck(accessToken,DELETE_QUESTION)){
            UserEntity user = userAuthTokenEntity.getUser();

            QuestionEntity existingQuestionEntity = questionValidy.checkQuestion(questionId);

            if (!user.equals(existingQuestionEntity.getUser_id()))  {
                throw new AuthorizationFailedException("ATHR-003", "Only the question owner or admin can delete the question");
            } else {
                questionDao.deleteUserByUUID(questionId);
                deletedQuestionid=questionId;
                return (deletedQuestionid);
            }
        }
        return deletedQuestionid;
    }
    @Transactional(propagation = Propagation.REQUIRED)
    public List<QuestionEntity> getAllQuestionsByUser(String accessToken, String userId) throws AuthorizationFailedException, UserNotFoundException {
        UserAuthEntity userAuthTokenEntity = userDao.userByAccessToken(accessToken);
        List<QuestionEntity> questionEntityList = new ArrayList<>();
        if (userDao.findUserByUuid(userId) == null) {
            throw new UserNotFoundException("USR-001", "User with entered uuid whose question details are to be seen does not exist");
        } else if (userAuthValidifierService.userAuthValidityCheck(accessToken,GET_QUESTION_BY_USER)) {
            UserEntity userEntity = userAuthTokenEntity.getUser();
            questionEntityList = questionDao.getQuestionByUser(userEntity);
            return questionEntityList;
        }
        return questionEntityList;
    }
}
