package com.upgrad.quora.service.entity;

import javax.persistence.*;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.time.ZonedDateTime;
@Entity
@Table(name="question")
@NamedQueries(
        {
                @NamedQuery(name = "questionEntityById", query = "select qe from QuestionEntity qe where qe.id = :id"),
                @NamedQuery(name = "questionEntityByUuid", query = "select qe from QuestionEntity qe where qe.uuid = :uuid"),
                @NamedQuery(name = "questionByUserId", query = "select qe from QuestionEntity qe inner join qe.user_id usr where usr.uuid = :uuid"),
                @NamedQuery(name = "allQuestions", query = "select qe from QuestionEntity qe"),
        }
)
public class QuestionEntity implements Serializable {
    @Id
    @Column(name="id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @Column(name="uuid")
    @Size(max=200)
    private String uuid;

    @Column(name="content")
    @Size(max=500)
    private String content;

    @Column(name="date")
    private ZonedDateTime date;

    @ManyToOne
    @JoinColumn(name="user_id", referencedColumnName = "id")
    private UserEntity user_id;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public ZonedDateTime getDate() {
        return date;
    }

    public void setDate(ZonedDateTime date) {
        this.date = date;
    }

    public UserEntity getUser_id() {
        return user_id;
    }

    public void setUser_id(UserEntity user_id) {
        this.user_id = user_id;
    }

}
