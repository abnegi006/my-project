package com.upgrad.quora.service.business;

import com.upgrad.quora.service.common.EndPointIdentifier;
import com.upgrad.quora.service.dao.UserDao;
import com.upgrad.quora.service.entity.UserAuthEntity;
import com.upgrad.quora.service.exception.AuthorizationFailedException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AuthorizationService implements EndPointIdentifier {
    @Autowired
    private UserDao userDao;

    @Autowired
    UserService userService;
    public UserAuthEntity getUserAuthEntity(String accessToken, String endpointIdentifier) throws AuthorizationFailedException {

        if (userDao.userByAccessToken(accessToken) == null) {

            throw new AuthorizationFailedException("ATHR-001", "User has not signed in");
        } else {

            String logout = String.valueOf(userDao.userByAccessToken(accessToken).getLogout_at());

            if (!logout.equals("null")) {
                String er = null;

                if (endpointIdentifier.equals(QUESTION_ENDPOINT)) {
                    er = QUESTION_ENDPOINT;
                } else if (endpointIdentifier.equals(ANSWER_ENDPOINT)) {
                    er = ANSWER_ENDPOINT;
                } else if (endpointIdentifier.equals(USER_ENDPOINT)) {
                    er = USER_ENDPOINT;
                }
                throw new AuthorizationFailedException("ATHR-002", er);
            } else {

                return userDao.userByAccessToken(accessToken);
            }

        }
    }
}
