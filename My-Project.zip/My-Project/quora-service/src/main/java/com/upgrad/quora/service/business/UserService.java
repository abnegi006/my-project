package com.upgrad.quora.service.business;

import com.upgrad.quora.service.dao.UserDao;
import com.upgrad.quora.service.entity.UserAuthEntity;
import com.upgrad.quora.service.entity.UserEntity;
import com.upgrad.quora.service.exception.SignOutRestrictedException;
import com.upgrad.quora.service.exception.UserNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.time.ZonedDateTime;


@Service
public class UserService {

    @Autowired
    private UserDao userDao;

    @Autowired
    private PasswordCryptographyProvider passwordCryptographyProvider;

    @Transactional(propagation = Propagation.REQUIRED)
    public UserEntity createUser(final UserEntity userEntity) {

        String password = userEntity.getPassword();
        if(password == null) {
            userEntity.setPassword("quora@123");
        }
        String[] encryptPassword = passwordCryptographyProvider.encrypt(userEntity.getPassword());
        String salt = encryptPassword[0];
        userEntity.setSalt(salt);
        userEntity.setPassword(encryptPassword[1]);
        return userDao.createUser(userEntity);
    }
    public UserEntity getUserByUserName(String userName){
        return userDao.userByUserName(userName);
    }
    public UserEntity getUserByEmail(String email) {
        return userDao.userByEmail(email);
    }
    public UserEntity getUserByUuid (String uuid) throws UserNotFoundException {
        if (userDao.findUserByUuid(uuid) == null) {
            throw new UserNotFoundException("USR-001", "User with entered uuid does not exist");
        } else {
            return userDao.findUserByUuid(uuid);
        }
    }
    @Transactional(propagation = Propagation.REQUIRED)
    public UserAuthEntity getUserAuthEntityByAccessToken(String accessToken) throws SignOutRestrictedException
    {
        UserAuthEntity userAuthEntity=userDao.userByAccessToken(accessToken);

        if(userAuthEntity==null)
        {
            throw new SignOutRestrictedException("SGR-001", "User is not Signed in");
        }
        else
        {
            final ZonedDateTime currTime=ZonedDateTime.now();
            userAuthEntity.setLogout_at(currTime);
            return userAuthEntity;
        }
    }
    }






