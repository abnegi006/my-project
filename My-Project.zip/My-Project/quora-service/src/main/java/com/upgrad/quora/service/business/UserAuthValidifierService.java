package com.upgrad.quora.service.business;

import com.upgrad.quora.service.common.EndPointIdentifier;
import com.upgrad.quora.service.dao.UserDao;
import com.upgrad.quora.service.entity.UserAuthEntity;
import com.upgrad.quora.service.exception.AuthorizationFailedException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserAuthValidifierService implements EndPointIdentifier {

    @Autowired
    UserDao userDao;

    boolean userAuthValidityCheck(String accessToken, String endpointIdentifier) throws AuthorizationFailedException {
        UserAuthEntity userAuthEntity = userDao.userByAccessToken(accessToken);

        if (userAuthEntity == null) {
            throw new AuthorizationFailedException("ATHR-001", "User has not signed in");

        } else {
            String logoutAt = String.valueOf(userDao.userByAccessToken(accessToken).getLogout_at());

            if (!logoutAt.equals("null")) {

                String errorMessage = null;
                switch (endpointIdentifier) {

                    case GET_ALL_QUESTIONS:
                        errorMessage = GET_ALL_QUESTIONS;
                        break;

                    case CHECK_QUESTION:
                        errorMessage = CHECK_QUESTION;
                        break;

                    case DELETE_QUESTION:
                        errorMessage = DELETE_QUESTION;
                        break;

                    case GET_QUESTION_BY_USER:
                        errorMessage = GET_QUESTION_BY_USER;
                        break;
                }

                throw new AuthorizationFailedException("ATHR-002",
                        errorMessage);
            } else {
                return true;
            }
        }
    }
}
