package com.upgrad.quora.service.business;

import com.upgrad.quora.service.dao.UserDao;
import com.upgrad.quora.service.entity.UserAuthEntity;
import com.upgrad.quora.service.entity.UserEntity;
import com.upgrad.quora.service.exception.AuthenticationFailedException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.time.ZonedDateTime;
@Service
public class AuthenticationService {

        @Autowired
        private UserDao userDao;
        @Transactional(propagation = Propagation.REQUIRED)
        public UserAuthEntity authenticate(final String userName, final String password) throws AuthenticationFailedException {
            UserEntity userEntity=userDao.userByUserName(userName);
            if(userEntity==null)
            {
                throw new AuthenticationFailedException("ATH-001","This username does not exist");
            }
            final String encryptedPassword=PasswordCryptographyProvider.encrypt(password,userEntity.getSalt());

            if(encryptedPassword.equals(userEntity.getPassword())){
                JwtTokenProvider token=new JwtTokenProvider(encryptedPassword);
                UserAuthEntity userAuthEntity=new UserAuthEntity();
                userAuthEntity.setUser(userEntity);
                userAuthEntity.setUuid(userEntity.getUuid());

                final ZonedDateTime currentTime=ZonedDateTime.now();
                final ZonedDateTime expiryTime=currentTime.plusHours(8);

                userAuthEntity.setAccess_token(token.generateToken(userEntity.getUuid(),currentTime,expiryTime));
                userAuthEntity.setLogin_at(currentTime);
                userAuthEntity.setExpires_at(expiryTime);

                userDao.createAuth(userAuthEntity);
                return userAuthEntity;
            }
            else
            {
                throw new AuthenticationFailedException("ATH-002", "Password failed");
            }
        }
    }
